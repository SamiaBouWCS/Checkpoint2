**Q.1.1 Pourquoi le ping avec les adresses IP des machines ne fonctionnent pas ?**

Le serveur et le client ne sont pas sur le même réseau. 

**Modifie la configuration sur le client pour que cela soit possible.**

Nouvelle adresse ip du client : 172.16.10.50


Explique ce que tu as fait et montre le par des copies d'écran.
Faire un clic droit sur me menu "Démarrer puis cliquer sur Connexions Réseaux ensuite sur Centre de réseaux et de partage puis modifier les parfamètres de la carte, clic droit du Ethernet psui sur Protocol Internet IPV4 puis Propriété". 

![Ceci est un exemple d’image](Checkpoint2-Q1.1bis.png)

![Ceci est un exemple d’image](Checkpoint2-Q1.1ter.png)

On doit avoir la copie d'écran d'un ping fonctionnel.

![Ceci est un exemple d’image](Checkpoint2-Q1.1.png)